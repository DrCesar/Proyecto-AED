/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Josue Jacobs #15275
 * @author Pablo Muñoz #15258
 * @author Josue Cifuentes #15041
 * @author Marcel Velásquez  #15534
 */
public class Lista {
    
    private Nodo raiz;
    private boolean error;
    
    public Lista(){
        
    }
    
    public Nodo addNodoRight(int val, Nodo t){
        Nodo temp =new Nodo(val);
        
        if(t == null || t.getRight() != null){
            error = true;
        }else{
            t.setRight(temp);
            temp.setLeft(t);
        }  
        
        return t;
    }
    
    public Nodo addNodoLeft(int val, Nodo t){
        Nodo temp =new Nodo(val);
        
        if(t == null || t.getLeft() != null){
            error = true;
        }else{
            t.setLeft(temp);
            temp.setRight(t);
        }  
        return t;
    }
    
    public Nodo addNodoUp(int val, Nodo t){
        Nodo temp =new Nodo(val);
        
        if(t == null || t.getUp() != null){
            error = true;
        }else{
            t.setUp(temp);
            temp.setDown(t);
        }  
        return t;
    }
    
    public Nodo addNodoDown(int val, Nodo t){
        Nodo temp =new Nodo(val);
        
        if(t == null || t.getDown() != null){
            error = true;
        }else{
            t.setDown(temp);
            temp.setUp(t);
        }  
        return t;
    }
    
    public Nodo getRaiz(){
        return this.raiz;
    }
    
    public void setRaiz(Nodo n){
        this.raiz = n;
    }
    
    
}
