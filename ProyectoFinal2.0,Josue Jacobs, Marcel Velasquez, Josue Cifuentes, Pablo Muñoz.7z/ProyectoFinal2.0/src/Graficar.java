import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Josue Jacobs #15275
 * @author Pablo Muñoz #15258
 * @author Josue Cifuentes #15041
 * @author Marcel Velásquez  #15534
 */
public class Graficar {
    private String miArchivito;
    
    public Graficar (String archivo){
         miArchivito = archivo; 
         
     }
    
    public int leerLineas() throws IOException{
         FileReader linea = new FileReader(miArchivito);
         BufferedReader tLineas = new BufferedReader(linea);
         
          String lineas; 
         int cantLineas = 0;
         
         while ((lineas = tLineas.readLine()) != null) {
             cantLineas++;
             
         
         }
         tLineas.close();
         
         return cantLineas;    
         
     
     }
     
     public String[] OpenFile() throws IOException{
         FileReader linea = new FileReader(miArchivito);
         BufferedReader tLineas = new BufferedReader(linea);
         
         int cantidadLineas = leerLineas();
         String[] datos = new String[cantidadLineas];
         for (int i=0; i <cantidadLineas; i++){
             datos[i] = tLineas.readLine();
             
         }
         
         tLineas.close();
      
         return datos;
        
     }
    
    
}
