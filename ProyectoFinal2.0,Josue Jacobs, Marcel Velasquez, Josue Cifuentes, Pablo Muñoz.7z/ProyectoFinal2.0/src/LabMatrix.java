/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Josue Jacobs #15275
 * @author Pablo Muñoz #15258
 * @author Josue Cifuentes #15041
 * @author Marcel Velásquez  #15534
 */
public class LabMatrix {
    
    private boolean error;
    private boolean resuelto;
    private int[][] maze;
    private String direc = "";
    
    public LabMatrix(int[][] ma){
        this.maze = ma;
        direc = "";
    }
    
    public void solveMaze(int x, int y){
        if(maze[x][y] == -3){
            System.out.println("Se resolvio el laberinto");
        }else{
            System.out.println(Integer.toString(x)+","+Integer.toString(y));
            if(deadEnd(x,y)){
                if(direc.equals(""))
                    direc = firstDirec(x,y);
                else
                    direc = invDirec(direc);
            }else{
                //maze[x][y] = maze[x][y] + 1;
                direc = newDirec(x,y);
            }
            maze[x][y] = maze[x][y] + 1;
            if(direc.equals("right"))
                solveMaze(x+1,y);
            else
                if(direc.equals("left"))
                    solveMaze(x-1,y);
                else
                    if(direc.equals("up"))
                        solveMaze(x,y+1);
                    else
                        if(direc.equals("down"))
                            solveMaze(x,y-1);
        }
    }
    
    public boolean deadEnd(int x, int y){
        int cont = 0;
        
        if(maze[x][y+1] == -1)
            cont++;
        if(maze[x][y-1] == -1)
            cont++;
        if(maze[x+1][y] == -1)
            cont++;
        if(maze[x-1][y] == -1)
            cont++;
        
        return cont == 3;
    }
    
    public String newDirec(int x, int y){
        String nDirec = "";
        int upV = 1000;
        int doV = 1000;
        int riV = 1000;
        int leV = 1000;
        
        
        if(maze[x][y+1]>=0 || maze[x][y+1]==-3)
            upV=maze[x][y+1];
        
        if(maze[x][y-1]>=0 || maze[x][y-1]==-3)
            doV=maze[x][y-1];
        
        if(maze[x+1][y]>=0 || maze[x+1][y]==-3)
            riV=maze[x+1][y];
        
        if(maze[x-1][y]>=0  || maze[x-1][y]==-3)
            leV=maze[x-1][y];
        
        if(direc.equals("right")){
            if(doV<=upV && doV<=riV)
                return "down";
            if(riV<=upV)
                return "right";
            return "up";
        }
        
        if(direc.equals("left")){
            if(upV<=doV && upV<=leV)
                return "up";
            if(leV<=doV)
                return "left";
            return "down";
        }
        
        if(direc.equals("up")){
            if(riV<=upV && riV<=leV)
                return "right";
            if(upV<=leV)
                return "up";
            return "left";
        }
        
        if(direc.equals("down")){
            if(leV<=doV && leV<=riV)
                return "left";
            if(doV<=riV)
                return "down";
            return "right";
        }
        
        return nDirec;
    }
    
    public String invDirec(String s){
        if(s.equals("right"))
            return "left";
        if(s.equals("left"))
            return "right";
        if(s.equals("up"))
            return "down";
        if(s.equals("down"))
            return "up";
        return s;
    }
    
    public String firstDirec(int x, int y){
        
        if(maze[x][y+1]>=0 || maze[x][y+1]==-3)
            return "up";
        
        if(maze[x][y-1]>=0 || maze[x][y-1]==-3)
            return "down";
        
        if(maze[x+1][y]>=0 || maze[x+1][y]==-3)
            return "right";
        
        if(maze[x-1][y]>=0  || maze[x-1][y]==-3)
            return "left";
        
        return "";
    }
    
}
