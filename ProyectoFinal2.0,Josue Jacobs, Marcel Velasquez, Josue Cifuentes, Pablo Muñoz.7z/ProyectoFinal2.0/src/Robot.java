/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Josue Jacobs #15275
 * @author Pablo Muñoz #15258
 * @author Josue Cifuentes #15041
 * @author Marcel Velásquez  #15534
 */
public class Robot implements Sensores {
    
    private int[][] maze;
    
    public Robot(){
        
    }
    
    public void recorerMaze(){
        
    }
    
    public void crearMaze(){
        
    }
    
}
