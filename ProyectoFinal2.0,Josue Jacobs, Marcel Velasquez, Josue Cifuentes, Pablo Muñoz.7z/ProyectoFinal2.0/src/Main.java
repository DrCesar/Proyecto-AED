
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Josue Jacobs #15275
 * @author Pablo Muñoz #15258
 * @author Josue Cifuentes #15041
 * @author Marcel Velásquez  #15534
 */
public class Main {
    
    /* Los numeros que se muestran en la pantalla son las posiciones en la que se encuentra el robot. 
    Se imprime las posiciones y el archivo .txt para que se pueda ver de la forma en como el robot esta
    solucionando el laberinto*/
       
    public static void main(String[] args) throws UnsupportedEncodingException {
        int[][] matrix = new int[25][25];
        int x = 0;
        int y = 0;
        
        URL location = Main.class.getResource("Main.class");
        String dir = location.getPath();
        
        String path = Main.class.getResource("Main.class").getFile();
        path = URLDecoder.decode(path, "UTF-8");
        
        LabMatrix pro;
        Laberinto pro2 = null;
        
        System.out.println(path);
        try(BufferedReader buff = new BufferedReader(new FileReader(path.substring(0,path.indexOf("Main"))+"maze.txt"))) {
            
            String linea;
            int j =0;
            while ((linea = buff.readLine()) != null){
                System.out.println(linea);
                for(int i = 0; i < linea.length(); i++){
                    if('x' == (int)linea.charAt(i)){
                        matrix[i][j] = -1; 
                    }
                    if(0 == (int)linea.charAt(i)){
                        matrix[i][j] = 0; 
                    }
                    if('e' == linea.charAt(i)){
                        matrix[i][j] = -3; 
                    }
                    if('s' == (int)linea.charAt(i)){
                        matrix[i][j] = 0; 
                        x = i;
                        y = j;
                    }
                }
                j++;
                
            }
            
            
        } catch(IOException e){
            e.printStackTrace();
        }
         
        
        System.out.println("Posición inicial: "+Integer.toString(x)+","+Integer.toString(y));      
        pro = new LabMatrix(matrix);
        pro2 = new Laberinto(matrix);
        
        


        //pro.solveMaze(x, y);
        
        
        pro2.solveMaze(pro2.getLista().getRaiz(),x, y);
        
        
    }
    
    
}
