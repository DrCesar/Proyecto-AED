/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Josue Jacobs #15275
 * @author Pablo Muñoz #15258
 * @author Josue Cifuentes #15041
 * @author Marcel Velásquez  #15534
 */
public class Nodo {
    
    private Nodo right;
    private Nodo left;
    private Nodo up;
    private Nodo down;
    
    private int value;
    
    public Nodo(){
        this.value = 0;
        
        this.right = null;
        this.left = null;
        this.down = null;
        this.up = null;
    }
    
    public Nodo(int i){
        this.value = i;
        
        this.right = null;
        this.left = null;
        this.down = null;
        this.up = null;
    }
    
    public void setRight(Nodo t){
        this.right = t;
    }
    
    public Nodo getRight(){
        return this.right;
    }
    
    public void setLeft(Nodo t){
        this.left = t;
    }
    
    public Nodo getLeft(){
        return this.left;
    }
    
    public void setUp(Nodo t){
        this.up = t;
    }
    
    public Nodo getUp(){
        return this.up;
    }
    
    public void setDown(Nodo t){
        this.down = t;
    }
    
    public Nodo getDown(){
        return this.down;
    }
    
    public int getValue(){
        return this.value;
    }
    
    
    public void setValue(int i){
        this.value = i;
    }
    
    
}
